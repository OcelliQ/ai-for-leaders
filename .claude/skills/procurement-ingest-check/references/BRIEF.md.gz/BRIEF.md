# Procurement brief: RFQ-ARER-26-014, ARER-300 research test platform

Prepared 2026-10-06 from the binding grant and tender record listed in §2. Source status is shown as **[B]** binding (signed, approved or issued) or **[C]** context only. Context sources explain the need; they do not set or change any requirement. This brief does not refer to, evaluate or rank any bid.

## 1. Purpose and decision

The Institute is buying one fixed-price "Advanced Retro-Encabulation Reliability Platform, ARER-300, for semiconductor packaging research" [B: RFQ-01 §1.1], with installation, Site Acceptance Test (SAT), operator training, warranty, maintenance and support [B: GRANT-01 §2.1; RFQ-01 §5.2]. It enables the grant-funded objective "to develop and validate lower-carbon materials for advanced semiconductor packaging" and a validated reliability dataset due 31 December 2029 [B: GRANT-01 §1.1, §3.2]. The evaluation panel applies the mandatory gate and weighted scoring and makes a recommendation; Mira Tan verifies process, Joel Lim checks budget, and the Executive Approval Committee makes the human decision [B: RFQ-01 §8.1; RFQ-05 §3.1].

## 2. Document inventory

| ID | Title | Version / date | Status (as labelled) | Role in this brief |
| --- | --- | --- | --- | --- |
| GRANT-01 | Grant award and project agreement | 1.0 / 2026-04-01 | signed | [B] Project term, objective, ceiling, change rule |
| GRANT-02 | Approved equipment budget schedule | 1.0 / 2026-04-01 | approved | [B] Ceiling split, excl-GST basis, finance checks |
| GRANT-03 | Milestones and deliverables annex | 1.0 / 2026-04-01 | signed | [B] Milestone dates and evidence |
| GRANT-04 | Approved project variation PV-01 | 1.0 / 2026-06-15 | approved | [B] Moves pilot checkpoint only |
| RFQ-01 | Open tender request RFQ-ARER-26-014 | 1.0 / 2026-07-06 | approved; issued 6 July 2026 | [B] Tender scope, dates, change rules |
| RFQ-02 | Mandatory requirements schedule | 1.0 / 2026-07-06 | approved (issued with RFQ) | [B] Gates M1–M7 |
| RFQ-03 | Technical specification for ARER-300 | 1.1 / 2026-07-20 | approved (issued) | [B] Capacity, ranges, export, SAT, training |
| RFQ-04 | Commercial response template | 1.0 / 2026-07-06 | template | [B] Price lines C1–C8 |
| RFQ-05 | Evaluation guide | 1.0 / 2026-07-06 | approved (issued) | [B] Gate use, weights, formula |
| RFQ-06 | Formal tender addendum register | 1.0 / 2026-08-28 | approved | [B] Addenda ADD-01, ADD-02; register closed |
| PLAN-01 | PI implementation and experiment plan | 1.1 / 2026-06-20 | draft | [C] Operational need and dependencies |
| EMAIL-01 | Internal clarification on project-end service | 10–11 Aug 2026 | correspondence | [C] Explains service-end intent |
| TECH-01 | Plain-language encabulation explainer | 1.0 / 2026-07-06 | approved (explainer) | [C] Terminology only |
| CASE-01 | Executive case brief (redacted text) | 1.0 / 2026-09-03 | generated summary | [C] Roles and status rules |

**Precedence rule:** the signed grant as varied by approved written variation sets project terms and the ceiling, and the issued RFQ as changed only by numbered formal addenda sets tender requirements; a variation or addendum changes only the term it expressly identifies, and context documents never override either [B: GRANT-01 §4.1, §7.2; RFQ-01 §2.1, §8.2; RFQ-06 §3.1; C: CASE-01 §4.3].

## 3. Mandatory gates M1–M7

The gate is conjunctive: "every mandatory item must be satisfied before a bid receives a weighted rank" [B: RFQ-02 §2.2]; "A failure on any one gate excludes the proposal from weighted ranking. An unknown price or conditional commitment cannot be scored as compliant" [B: RFQ-05 §1.1].

| ID | Exact requirement [B: RFQ-02 T1] | Evidence required [B: RFQ-02 T1] | Supporting locators |
| --- | --- | --- | --- |
| M1 | "Total evaluated price ≤ S$450,000 excluding GST" | Submitted commercial schedule | RFQ-02 T1 M1; RFQ-04 T1 C6; GRANT-02 T1 |
| M2 | "SAT by 31 January 2027" | Submitted implementation plan | RFQ-02 T1 M2; GRANT-03 T1 row 1 |
| M3 | "At least 48 specimens per run across specified ranges" | Submitted technical schedule | RFQ-02 T1 M3; RFQ-03 §1.1–§1.2 |
| M4 | "Raw readings and event logs export as CSV or JSON without continuing hosted service" | Submitted technical schedule | RFQ-02 T1 M4; RFQ-03 §2.1, §4.1 |
| M5 | "Price includes installation, SAT and training for eight staff" | Submitted commercial and implementation schedules | RFQ-02 T1 M5; RFQ-04 T1 C3–C4; RFQ-06 T1 ADD-02 |
| M6 | "Warranty, two PM visits yearly and two-business-day response from SAT through 31 March 2030" | Submitted service schedule | RFQ-02 T1 M6; RFQ-04 T1 C5 |
| M7 | "Mandatory commitment documented in the submitted proposal or a formal pre-close addendum" | Submitted record and RFQ-06 | RFQ-02 T1 M7; RFQ-01 §4.1; RFQ-06 §2 |

"Specified ranges" for M3 are: "at least 48 specimens simultaneously in one controlled run", each position with "synchronised temperature, mechanical load and electrical bias"; "Sequential batches are not equivalent to one run"; ranges "−40 °C to 125 °C, 0 to 500 N load and 0 to 24 V electrical bias" [B: RFQ-03 §1.1, §1.2].

**Evidence conventions** [B: RFQ-02 §3.1]: M1 uses "the complete evaluated price excluding GST" reconciled with required inclusions; M2 uses "the committed Site Acceptance Test date rather than shipment or installation"; M3 and M4 use "the delivered technical configuration and export capability"; M5 and M6 "require a read across commercial, implementation and service records"; M7 asks "whether a claimed mandatory obligation actually entered the submitted tender record by close". Record each failed or unresolved gate "with the exact source passage" [B: RFQ-02 §3.2], and record source, clause or row, quoted value and status for every gate [B: RFQ-05 §4.1].

## 4. Scored criteria

| Criterion [B: RFQ-05 T1] | Weight | Scoring basis (exact) |
| --- | --- | --- |
| Technical performance and useful capacity | 35% | "Locked 0–100 panel score; excess capacity receives diminishing benefit" |
| Total evaluated lifecycle cost | 30% | "Locked 0–100 panel score based on complete included cost and price bands" |
| Delivery, installation and training | 20% | "Locked 0–100 panel score against plan credibility and lead time" |
| Service above mandatory minimum | 15% | "Locked 0–100 panel score; minimum compliance alone is not full marks" |

Weights sum to 35 + 30 + 20 + 15 = 100%. Formula: "total = 0.35×technical + 0.30×lifecycle cost + 0.20×delivery/training + 0.15×service". Rounding: "Round the sum to one decimal place". No renormalisation: scores "remain fixed when another bid fails a gate; they are not renormalised by bidder set" [B: RFQ-05 §2.2; also §4.2]. Only gate-passing bids are scored and ranked [B: RFQ-05 §1.1, §4.2].

## 5. Budget

Ceiling: "up to S$450,000 excluding GST for the ARER-300 platform, inclusive of mandatory equipment, installation, acceptance testing, training, warranty, maintenance and support" [B: GRANT-01 §2.1]; unchanged by PV-01 [B: GRANT-04 §2].

| GRANT-02 T1 category | S$ ex GST |
| --- | --- |
| Core platform and mandatory options | 360000 |
| Installation, SAT and training | 30000 |
| Warranty, maintenance and support | 60000 |
| Total equipment ceiling | 450000 |

Basis: Singapore dollars excluding GST; GST "must be identified separately" and is excluded from the M1 comparison [B: GRANT-02 §1, §2.2; RFQ-01 §3.1; RFQ-04 T1 C7]. The evaluated price is C6 "Total evaluated price" = "SUM(C1:C5), excluding GST", covering C1 base instrument (fixed), C2 mandatory options, C3 installation and SAT, C4 eight-person training, and C5 "Warranty, maintenance and support through 2030-03-31"; C8 exclusions and options "Must not conceal mandatory cost" [B: RFQ-04 T1 C1–C8]. Only the total controls: "The total is the controlling ceiling; an individual line is not a separate authorisation to omit a required item" [B: GRANT-02 §2.1]; categories are "planning allocations" [B: GRANT-01 §6.2]. Unpriced or future options do not satisfy a mandatory requirement and a later unpriced service request "cannot be presumed to fit" [B: RFQ-01 §3.1; GRANT-01 §6.1]. Finance (Joel Lim) reconciles component sums to the stated total and records GST separately [B: GRANT-02 §2.2, T2, §4.1; RFQ-05 §3.1].

## 6. Delivery, acceptance and training

- **SAT deadline:** "SAT by 31 January 2027" [B: RFQ-02 T1 M2], matching "Equipment commissioned 2027-01-31" evidenced by a "Site Acceptance Test record" [B: GRANT-03 T1]. A dependency "does not shift a firm submitted SAT date unless the tender record is formally changed" [B: RFQ-01 §7.2].
- **SAT must demonstrate:** installed configuration, "simultaneous specimen operation across the required control ranges, raw-data export, event logging and operator handover"; open items with owner and resolution date; acceptance "should not be inferred from shipment or installation alone" [B: RFQ-01 §7.1]. The supplier should "show a configured run, export a sample file, reconcile selected values with the controller display and demonstrate an event log entry" [B: RFQ-03 §4.2]. Representative specimens or simulator loads are allowed if the record demonstrates "the supplied position count, operating controls and export function" [B: RFQ-01 §10.2]. The commissioning record identifies configuration, serial identifiers, procedure, results, open items and signatures [B: GRANT-03 §3.1].
- **Training:** the supplier "trains eight staff on site" [B: RFQ-03 §2.1], included in price [B: RFQ-02 T1 M5; RFQ-04 T1 C4], using the delivered configuration with "a hands-on export exercise" [B: RFQ-03 §5.1].
- **Addenda:** ADD-01 (2026-07-20) "Test temperature wording; −40 °C endpoint retained"; ADD-02 (2026-08-05) "On-site training venue and eight-person class confirmed" [B: RFQ-06 T1]. Neither "changes the evaluated price basis, final service date or method of recording a bidder-specific amendment" [B: RFQ-06 §3.2].

## 7. Service and support

Requirement: "Warranty, two PM visits yearly and two-business-day response from SAT through 31 March 2030" [B: RFQ-02 T1 M6], priced in C5 "through 2030-03-31" [B: RFQ-04 T1 C5]. **Start:** SAT. **End:** 31 March 2030. The service schedule should state "the start basis, final covered date, maintenance cadence and response undertaking" [B: RFQ-01 §9.2].

Why 31 March 2030: the validated dataset is due 2029-12-31 and project close-out is 2030-03-31 [B: GRANT-03 T1]; the project must "maintain an operational test platform for verification and close-out through 31 March 2030" [B: GRANT-01 §3.2]; "reliable operation and support through 31 March 2030 matter to the funded result" [B: GRANT-03 §2], and the project end is "a practical planning boundary for service continuity" [B: GRANT-03 §3.3]. PV-01 moved only the pilot checkpoint and parties should not extrapolate service from it [B: GRANT-04 §3.1, §3.2]. Context (not a requirement): the PI asked that support run to 31 March 2030 "rather than stopping when the dataset is first delivered", and Procurement replied that the issued schedule already states this date [C: EMAIL-01#INT-M01, #INT-M02; PLAN-01 §5.2].

## 8. Key dates

| Date | Event | Source |
| --- | --- | --- |
| 2026-04-01 | Project start | [B] GRANT-01 §1.1 |
| 2026-07-06 | Tender issued | [B] RFQ-01 §2.1 |
| 2026-07-20 | ADD-01 issued; RFQ-03 v1.1 | [B] RFQ-06 T1; RFQ-03 header |
| 2026-08-05 | ADD-02 issued | [B] RFQ-06 T1 |
| 2026-08-14 | Written clarification questions due | [B] RFQ-01 §2.1 |
| 2026-08-28 17:00 SGT | Tender close; addendum register closed | [B] RFQ-01 §2.1; RFQ-06 §2 |
| 2026-09-30 | Target tender decision and PO (draft plan only) | [C] PLAN-01 T1 |
| 2027-01-31 | SAT / equipment commissioned | [B] RFQ-02 T1 M2; GRANT-03 T1 |
| 2028-03-31 | Pilot checkpoint, varied from 2028-02-28 by PV-01 | [B] GRANT-04 §1 |
| 2029-12-31 | Validated reliability dataset due | [B] GRANT-01 §3.2; GRANT-03 T1 |
| 2030-03-31 | Project close-out; end of required service | [B] GRANT-03 T1; RFQ-02 T1 M6 |

## 9. Rules on clarifications and changes

| Instrument | Binding? | Source |
| --- | --- | --- |
| Numbered formal addendum issued by Procurement before close | Yes: the only route to change a tender requirement | [B] RFQ-01 §2.1; RFQ-06 §3.1, §4.1 |
| Bidder's formal revision accepted into the tender record by close | Yes, for that bidder's commitment | [B] RFQ-01 §4.1, §8.2 |
| Clarification explaining existing submitted wording | No new obligation; may explain; status kept in evidence chain | [B] RFQ-01 §4.1; RFQ-02 §2.2, §3.2 |
| Email, conditional statement, expectation, pending approval | Not an amendment; "an email exchange is not itself a numbered addendum" | [B] RFQ-01 §4.1; RFQ-06 §3.1 |
| Post-close explanation | Cannot add "a new price, warranty term or capability"; cannot retroactively insert a document | [B] RFQ-01 §6.2; RFQ-06 §4.2 |
| Grant change | Effective only as approved in a written variation; an operational forecast does not vary the grant | [B] GRANT-01 §4.1, §7.2 |

Only ADD-01 and ADD-02 were issued; "No other addendum was issued before close" [B: RFQ-06 §2].

## 10. Roles and approvals

| Check | Owner | Source |
| --- | --- | --- |
| Research need, technical rationale | Dr. Anika Rao, PI | [B] GRANT-01 §1.1; [C] CASE-01 T4 |
| Mandatory gate and criterion scores | Evaluation Panel | [B] RFQ-01 §8.1; RFQ-05 §3.1 |
| Process, clarification status, bidder contact, committee submission | Mira Tan, Procurement Reviewer | [B] RFQ-05 §3.1, §6.2; [C] CASE-01 §5.1–§5.2 |
| Budget and excl-GST reconciliation | Joel Lim, Finance Reviewer | [B] RFQ-05 §3.1; GRANT-01 T2 |
| Award decision | Executive Approval Committee | [B] RFQ-01 §8.1; RFQ-05 §3.1 |

An AI assistant **may** help prepare calculations and presentation material and draft working analysis for human checking [C: CASE-01 §5.3]. It **may not** contact a bidder, amend the tender, select a supplier, initiate award or confer authority belonging to Procurement or the committee [C: CASE-01 §5.1, §5.3]; "A workbook or AI memo is a derived aid and is not itself an award" [B: RFQ-05 §3.1].

## 11. Unresolved questions and ambiguities

| # | Issue | Sources | Resolver |
| --- | --- | --- | --- |
| Q1 | M4 wording differs: "without continuing hosted service" (T1) vs "without hosted subscription" (workbook) vs "without an ongoing vendor-hosted service". Which text governs? | RFQ-02 T1 M4; RFQ-02 workbook row 5; RFQ-03 §2.1 | Mira Tan |
| Q2 | M5 evidence differs: "commercial and implementation schedules" (T1) vs "commercial schedule" (workbook). | RFQ-02 T1 M5; RFQ-02 workbook row 6; RFQ-02 §3.1 | Mira Tan |
| Q3 | M6 does not define "business day" (calendar), how "two PM visits yearly" applies to part-years between SAT and 31 March 2030, whether "yearly" is calendar or contract year, or the scope of "warranty". | RFQ-02 T1 M6; RFQ-04 T1 C5 | Mira Tan with Dr. Rao |
| Q4 | Texts of ADD-01 and ADD-02 are not in the source set; only register summaries and RFQ-03 §1.2 describe them. | RFQ-06 T1, §3.2; RFQ-03 §1.2 | Mira Tan |
| Q5 | M7 "formal pre-close addendum": RFQ-06 lists only Institute-issued addenda, while RFQ-01 refers to a bidder's "formal revision accepted into the tender record". How a bidder-specific amendment is recorded is not specified. | RFQ-02 T1 M7; RFQ-01 §4.1; RFQ-06 §2, §3.2 | Mira Tan |
| Q6 | The "price bands" for the lifecycle-cost criterion are not defined, and it is not stated whether "lifecycle cost" equals the C6 evaluated price. | RFQ-05 T1; RFQ-04 T1 C6 | Mira Tan and Joel Lim |
| Q7 | No scoring rubric is given for "diminishing benefit" on excess capacity, "plan credibility and lead time", or service above minimum. | RFQ-05 T1 | Evaluation Panel via Mira Tan |
| Q8 | The "process-approved resolution" for arithmetic differences between component lines and a stated total is not specified. | GRANT-02 §2.2, §4.1 | Joel Lim with Mira Tan |
| Q9 | The draft plan's 2026-09-30 decision target has passed (today 2026-10-06); the effect on achieving SAT by 31 January 2027 is not recorded. This is context only and does not change M2. | PLAN-01 T1; RFQ-02 T1 M2 | Dr. Rao, routed via Mira Tan |
